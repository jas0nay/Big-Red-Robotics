package org.firstinspires.ftc.teamcode.jason;

import com.acmerobotics.roadrunner.Action;
import com.acmerobotics.roadrunner.SequentialAction;
import com.acmerobotics.roadrunner.ftc.Actions;
import com.acmerobotics.roadrunner.Pose2d;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.acmerobotics.roadrunner.Vector2d;

import org.firstinspires.ftc.teamcode.MecanumDrive;

@Autonomous (name="Skibidi Sigma")
public class SkibidiSigma extends LinearOpMode {

    @Override
    public void runOpMode() throws InterruptedException{

        Pose2d beginPose = new Pose2d(new Vector2d(-70, 24), Math.toRadians(0));

        MecanumDrive drive = new MecanumDrive(hardwareMap, beginPose);

        waitForStart();

        Action path = drive.actionBuilder(beginPose)
                .splineToSplineHeading(new Pose2d(30, -12, Math.toRadians(135)), Math.toRadians(180))
                .waitSeconds(1)
                .splineToSplineHeading(new Pose2d(-70, 24, Math.toRadians(0)), Math.toRadians(180))
                .build();
        Actions.runBlocking(new SequentialAction(path));
    }
}
